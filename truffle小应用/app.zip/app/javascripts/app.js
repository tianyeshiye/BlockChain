﻿// Import the page's CSS. Webpack will know what to do with it.
import "../stylesheets/app.css";

// Import libraries we need.
import { default as Web3} from 'web3';
import { default as contract } from 'truffle-contract'
import { default as HDWalletProvider } from 'truffle-hdwallet-provider'
import { default as Mnemonic } from 'bitcore-mnemonic'
import { default as Tx } from 'ethereumjs-tx'

// Import our contract artifacts and turn them into usable abstractions.
import metacoin_artifacts from '../../build/contracts/MetaCoin.json'

// MetaCoin is our usable abstraction, which we'll use through the code below.
var MetaCoin = contract(metacoin_artifacts);

var account;
var web3Provider;
var txNonce = 0;

window.App = {
  start: function() {
    var self = this;
    var code = new Mnemonic(128, Mnemonic.Words.ENGLISH);
    console.log(code.toString());
    web3Provider = new HDWalletProvider(code.toString(), "http://192.168.75.135:8545");
    var myaddress = web3Provider.address;
    var myPrivKey = web3Provider.wallet._privKey.toString('hex');
    MetaCoin.setProvider(web3Provider);

    // Get the initial account balance so it can be displayed.
    web3.eth.getAccounts(function(err, accs) {
      if (err != null) {
        alert("There was an error fetching your accounts.");
        return;
      }

      if (accs.length == 0) {
        alert("Couldn't get any accounts! Make sure your Ethereum client is configured correctly.");
        return;
      }

      document.getElementById("account1").value = accs[0];
      document.getElementById("eth_account1").value = accs[0];
      self.refreshBalance("balance1", accs[0]);
      self.refreshEthBalance("eth_balance1", accs[0]);

      document.getElementById("seed").value = code.toString();
      document.getElementById("wallet").value = myaddress;
      document.getElementById("priKey").value = myPrivKey;
    });
  },

  setStatus: function(message) {
    var status = document.getElementById("status");
    status.innerHTML = message;
  },

  setProvider: function () {
      var seed = document.getElementById("seed").value;
      web3Provider = new HDWalletProvider(seed, "http://192.168.75.135:8545");
      document.getElementById("wallet").value = web3Provider.address;
      document.getElementById("priKey").value = web3Provider.wallet._privKey.toString('hex');
      MetaCoin.setProvider(web3Provider);
  },

  refreshBalance: function(p_balance,p_account) {
    var self = this;
    var meta;
    var account1 = document.getElementById("account1").value;
    MetaCoin.deployed().then(function(instance) {
      meta = instance;
      return meta.getBalance.call(p_account, {from: account1});
    }).then(function(value) {
       document.getElementById(p_balance).value=value;
    }).catch(function(e) {
      console.log(e);
      self.setStatus("Error getting balance; see log.");
    });
  },

  refreshEthBalance: function (p_balance, p_account) {
      return new Promise((resolve, reject) => {
          web3.eth.getBalance(p_account, (error, result) => {
              if (error) {
                  reject(self.setStatus(error))
              } else {
                  resolve(document.getElementById(p_balance).value = result)
              }
          })
      });
  },

  unlockAccount: function(p_account,p_pwd) {
    var self = this;
    return new Promise((resolve, reject) => {
          web3.personal.unlockAccount(p_account, p_pwd, 10000,(error, result) => {
              if (error) {
                  reject(error)
              } else {
                  resolve(result)
              }
          })
    });
  },

  isAccountLocked: function (from, to, amount) {
      try {
          web3.eth.sendTransaction({
              from: from,
              to: to,
              value: amount
          });
          return true;
      } catch (err) {
          this.setStatus(err);
          return false;
      }
  },

  sendEth: function () {
      var from = document.getElementById("eth_from").value;
      var to = document.getElementById("eth_to").value;
      var amount = document.getElementById("eth_amount").value;
      var sendType = document.getElementsByName("ethSendType")[0].checked; 
      var privateKey = document.getElementById("priKey").value;
      var buffer_privateKey = new Buffer(privateKey, 'hex');
      if (sendType == true) {
          try {
              this.isAccountLocked(from, to, amount);
          } catch (err) {
              this.setStatus(err);
          }
      } else {
          var gasPrice = web3.eth.gasPrice;
          var nonce = web3.eth.getTransactionCount(from);
          var rawTx = {
              nonce: nonce,
              gasPrice: web3.toHex(gasPrice),
              gasLimit: web3.toHex(300000),
              to: to,
              value: web3.toHex(amount),
              data: ''
          }
          var tx = new Tx(rawTx);
          tx.sign(buffer_privateKey);
          var serializedTx = tx.serialize();
          console.log('0x' + serializedTx.toString('hex'));
          web3.eth.sendRawTransaction('0x' + serializedTx.toString('hex'), function (err, hash) {
              if (!err) {
                  console.log(hash);
              } else {
                  console.log(err);
              }
          });
      }
  },

  sendTocken: function() {
    var self = this;

    var amount = parseInt(document.getElementById("token_amount").value);
    var fromAccount = document.getElementById("token_from").value;
    var toAccount = document.getElementById("token_to").value;
    var sendType = document.getElementsByName("tokenSendType")[0].checked;

    if (sendType == true) {
        var psw = "123456";
        var lockResult = self.isAccountLocked(fromAccount, fromAccount, 0);
        if (!lockResult) {
            console.log("Account " + fromAccount + " is locked. Unlocking")
            self.unlockAccount(fromAccount, psw).then((value) => {
                self.setStatus("Unlock is OK!");
            }).catch((error) => {
                self.setStatus(error);
                return;
            });
        }
        MetaCoin.setProvider(web3.currentProvider);
    } else {
        MetaCoin.setProvider(web3Provider);
    }
    
    var meta;
    MetaCoin.deployed().then(function(instance) {
      meta = instance;
      return meta.sendCoin(toAccount, amount, {from: fromAccount});
    }).then(function (result) {
        for (var i = 0; i < result.logs.length; i++) {
            var log = result.logs[i];
            if (log.event == "Transfer") {
                self.setStatus("Transaction complete!");
                break;
            }
        }
    }).catch(function(e) {
      console.log(e);
      self.setStatus("Error sending coin; see log.");
    });
  }
};

window.addEventListener('load', function() {
    // Checking if Web3 has been injected by the browser (Mist/MetaMask)
    if (typeof web3 !== 'undefined') {
        // Use Mist/MetaMask's provider
        window.web3 = new Web3(web3.currentProvider);
    } else {
        // fallback - use your fallback strategy (local node / hosted node + in-dapp id mgmt / fail)
        window.web3 = new Web3(new Web3.providers.HttpProvider("http://192.168.75.135:8545"));
    }

  App.start();
});
